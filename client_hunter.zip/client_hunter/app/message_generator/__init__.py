from .generator import generate_message
